<?php
header('Location: ./views/login.php');
exit();
//MODELO Modular View Controller (MVC?)
?>