<?php
# O CONTROLLER FAZ OS TRATAMENTOS 
#CRIA UMA CLASSE CHAMADA USUARIO E CRIA FUNÇÕES (COISAS PRA USAR NO CÓDIGO)
#DEPOIS VAI DAR PRA USAR VALIDARUSUARIO() E CADASTRARUSUARIO()


require_once '../models/usuarioModel.php';


class usuarioController
{
    public function validarUsuario(string $email, string $senha)
    {
        $email = str_replace(' ', '', $email);
        $senha = md5(str_replace(' ', '', $senha)); #MD5 cria uma criptografia pro banco de dados
        #CHAMA FUNÇÃO USUARIOMODEL E FAZ A AÇÃO BUSCAR USUARIO POR...
        $usuarioModel = new usuarioModel();
        $retorno = $usuarioModel->buscar_Usuario_Por_Email_e_Senha($email, $senha);

        if (count($retorno) > 0) {
            echo "Usuário Encontrado";
        } else {
            echo "Usuário Não encontrado";
        }
    }
    public function cadastrarUsuario(string $nome, string $email, string $senha)
    {
        $nome = str_replace(' ', '', $nome);
        $email = str_replace(' ', '', $email);
        $senha = str_replace(' ', '', $senha);
        #CHAMA FUNÇÃO USUARIOMODEL E FAZ A AÇÃO BUSCAR USUARIO POR...
        $usuarioModel = new usuarioModel();
        $usuarioModel->inserir_usuario($nome, $email, $senha);
    }
}
