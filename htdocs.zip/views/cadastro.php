<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <style>
        body {
            background-image: linear-gradient(90deg, pink, RGB(255, 100, 200));
            font-family: Arial, Helvetica, sans-serif;
            color: white;
            font-size: larger;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: black;
        }

        main {
            text-align: center;
        }

        .box {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 20px;
            border: 2px solid black;
            max-width: 400px;
            width: 100%;
        }

        form {
            background-color: pink;
            padding: 20px;
        }

        .submitBUTTON {
            width: 100%;
            background-color: white;
            border: none;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: larger;
            cursor: pointer;
            transition: background-color 0.3s ease;
            border: 1px solid black;
            color: black;
        }

        .submitBUTTON:hover {
            background-color: white;
            color: pink;
        }

        .nome {
            color: white;
        }
    </style>

</head>

<body>
    <main>
        <div class="box">
            <h1 class="nome">CADASTRO DE USUÁRIO</h1>
            <form action="../routers/usuarioRouter.php" method="post">
                <label for="nome">Nome</label>
                <br>
                <input type="text" name="nome" id="nome" required>
                <br>
                <label for="email">E-mail</label>
                <br>
                <input type="email" name="email" id="email" required>
                <br>
                <label for="senha">Senha</label>
                <br>
                <input type="password" name="senha" id="senha" required>
                <br>
                <br>
                <input type="hidden" name="rota" id="rota" value="cadastrar">
                <input type="submit" value="Cadastrar" class="submitBUTTON">
            </form>
        </div>
    </main>

</body>

</html>