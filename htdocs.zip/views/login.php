<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background-image: linear-gradient(90deg, pink, RGB(255,100,200));
            font-family: Arial, Helvetica, sans-serif;
            color: white;
            font-size: larger;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        main {
            text-align: center;
        }

        .box {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 20px;
            border: 2px solid black;
            max-width: 400px;
            width: 100%;
        }

        form {
            background-color: palevioletred;
            padding: 30px;
            border-radius: 15px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: white;
        }

        input[type="email"],
        input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: larger;
        }

        .submitBUTTON {
            width: 100%;
            background-color: pink;
            border: none;
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: larger;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submitBUTTON:hover {
            background-color: white;
            color: pink;

        }

        a {
            color: white;
            text-decoration: none;
            font-size: larger;
        }

        a:hover {
            text-decoration: underline;

        }
    </style>
</head>

<body>
    <main>
        <div class="box">
            <h1>PORTAL DE NOTÍCIAS</h1>
            <form action="../routers/usuarioRouter.php" method="post">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
                <label for="senha">Senha</label>
                <input type="password" name="senha" id="senha" required>
                <input type="hidden" name="rota" id="rota" value="entrar">
                <input type="submit" value="Entrar" class="submitBUTTON">
            </form>
            <br>
            <a href="cadastro.php">Cadastre-se</a>
        </div>
    </main>
</body>

</html>
