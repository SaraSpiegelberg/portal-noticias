<?php

#CHAMA A PÁGINA CONEXAO
require 'conexao.php';

class usuarioDAO
{
    public function buscar_Usuario_Por_Email_e_Senha(string $email, string $senha)
    {
        #CHAMA FUNÇÃO CONEXAO E FAZ A AÇÃO PEGARCONEXAO...
        $conexao = (new CONEXAO())->pegarConexao();
        #FAZ A FUNÇÃO SQL E COLOCA EM UMA VARIAVEL 
        $sql = "SELECT * FROM usuario WHERE emailUsuario = :email AND senhaUsuario = :senha;";

        #CHAMA A CONEXAO E "prepara" para o QUERY PARA ENVIAR O CODIGO SQL
        $stmt = $conexao ->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha',$senha);

        #FETCHALL É PARA PESQUISAR COISAS NA TABELA
        $retorno = $stmt->fetchAll();

        return $retorno;
    }
    public function inserir_usuario(string $nome, string $email, string $senha)
    {
        #Inicia TODA CONEXÃO COM BANCO DE DADOS;
        $conexao = (new CONEXAO())->pegarConexao();
        #INSIRE DADOS dentro de uma variavel
        $sql = "INSERT INTO usuario VALUES(null,:idTipoUsuario,:nome,:email,:senha);";
        
        $stmt = $conexao->prepare($sql);
        #bindValue é quando passa um valor especifico para um parametro 
        $stmt->bindValue(':idTipoUsuario', 2);
        #bindparam é quando passa uma variavel como parametro :nome é igual a $nome
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);
        #INSERT UPDATE DELETE É EXECUTE;
        $retorno = $stmt->execute();

        return $retorno;
    }
}
