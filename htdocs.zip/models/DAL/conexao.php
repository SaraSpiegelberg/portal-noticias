<?php
class CONEXAO {
    public function pegarConexao(){
        $conexao = new PDO('mysql:host=localhost;dbname=portal_noticias','root','');
        return $conexao;
    }
}