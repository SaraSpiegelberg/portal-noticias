<?php

require_once 'DAL/usuarioDAO.php';

class usuarioModel {
    public function buscar_Usuario_Por_Email_e_Senha (string $email, string $senha){
        #CHAMA FUNÇÃO USUARIODAO E FAZ A AÇÃO BUSCAR USUARIO POR...
        $usuarioDAO = new usuarioDAO ();
        $retorno = $usuarioDAO ->buscar_Usuario_Por_Email_e_Senha($email,$senha);
        return $retorno;
    }
    public function inserir_usuario(string $nome, string $email, string $senha){
    
    }
}

?>