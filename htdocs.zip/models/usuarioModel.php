<?php

class usuarioModel {
    public function buscar_Usuario_Por_Email_e_Senha (string $email, string $senha){}
    public function inserir_usuario(string $nome, string $email, string $senha){}
}

?>